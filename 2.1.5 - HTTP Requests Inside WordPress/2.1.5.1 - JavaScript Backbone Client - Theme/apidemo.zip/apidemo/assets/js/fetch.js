const h1 = document.querySelector('h1.entry-title');
const articleEl = document.querySelector('div.entry-content');

fetch('http://api-demo.dev/wp-json/wp/v2/posts/1')
  .then(
    function(response) {
      if (response.status !== 200) {
        console.log('Looks like there was a problem. Status Code: ' +
          response.status);
        return;
      }

      // Examine the text in the response
      response.json().then(function(data) {
				// h1.innerHTML = data.title.rendered;
				// articleEl.innerHTML = data.content.rendered;
        console.log(data);
      });
    }
  )
  .catch(function(err) {
    console.log('Error: ', err);
  });
