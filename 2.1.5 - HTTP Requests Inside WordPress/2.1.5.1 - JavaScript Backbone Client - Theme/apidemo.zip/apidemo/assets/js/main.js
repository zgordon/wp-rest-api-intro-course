(function($) {
	const articleContainer = $('main#main'),
				title = $('.title-editor'),
				saveBtn = $('#save-post');

	function init() {
		loadPosts();
	};
	init();

	function loadPosts() {
		let posts = new wp.api.collections.Posts();
		posts.fetch({ data: { per_page: 25 } }).done( () => {
			clearPosts();
			posts.each(function(post) {
					loadPost( post.attributes );
		    });
		});
	}

	function clearPosts() {
		$(articleContainer).html('');
	}
	function clearForm() {
		$(title).val('');
		tinyMCE.activeEditor.setContent('');
	}
	function loadPost( post ) {
		let article = $('<article class="post"></article>'),
				titleLink = $('<a></a>').attr( 'href', post.link ).text( post.title.rendered ),
				title = $('<h2 class="entry-title"></h2>').append( titleLink ),
				content = $('<div class="entry-content"></div>').html( post.content.rendered );

		$(article).append(title).append(content);
		$(articleContainer).append(article) ;
	}

	$(saveBtn).click(function(){
		const post = {
				'title': $(title).val(),
				'content': tinyMCE.activeEditor.getContent(),
				'status': 'publish'
			};
		let newPost = new wp.api.models.Post( post );

		event.preventDefault();
		console.log( 'Here' );

		newPost.save().done(function(){
			clearForm();
			loadPosts();
		});

	});

// http://wordpress.stackexchange.com/questions/42652/how-to-get-the-input-of-a-tinymce-editor-when-using-on-the-front-end
	function get_tinymce_content(){
	    if ($("#wp-content-wrap").hasClass("tmce-active")){
	        return tinyMCE.activeEditor.getContent();
	    }else{
	        return $('#editor').val();
	    }
	}

})( jQuery );
